// Seleciona todos os elementos HTML com a classe 'item-menu' e os armazena em uma variável chamada menuItem.
var menuItem = document.querySelectorAll('.item-menu');

// Função que será executada quando um item de menu for clicado.
function link_select() {
    // Loop que percorre todos os elementos em menuItem.
    for (var i = 0; i < menuItem.length; i++) {
        // Remove a classe 'ligado' de todos os itens de menu, desativando-os visualmente.
        menuItem[i].classList.remove('ligado');
    }

    // Adiciona a classe 'ligado' ao item de menu atual que foi clicado.
    this.classList.add('ligado'); /* 'this' se refere ao item de menu clicado */
}

// Adiciona um ouvinte de evento de clique a cada item de menu.
for (var i = 0; i < menuItem.length; i++) {
    menuItem[i].addEventListener('click', link_select);
}

// Expansão do menu lateral

var btnExp = document.querySelector('#btn-exp')
var menuBurg = document.querySelector('.menu-lateral')

btnExp.addEventListener('click', function(){
    menuBurg.classList.toggle('expansao')
})

// Fechar o menu ao clicar em qualquer lugar fora do menu
document.addEventListener('click', function(event) {
    var CloseMenu = menuBurg.contains(event.target) || btnExp.contains(event.target);

    // Se o menu estiver expandido, e o click for por fora o menu ira fechar
    if (!CloseMenu && menuBurg.classList.contains('expansao')) {
        menuBurg.classList.remove('expansao');
    }
});

// validação dos campos
const form = document.getElementById('form');
const campos = document.querySelectorAll('.required');
const spans = document.querySelectorAll('.span-required');
// Expressão regular para validar o formato do email
const emailRegex = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,})+$/;

// Adiciona um ouvinte de evento para o envio do formulário
form.addEventListener('submit', function(event) {
    event.preventDefault();         // Impede o envio padrão do formulário
    if (validateForm()) {           // Se o formulário for validado com sucesso
        form.submit();
    }
});

// Define a função para adicionar estilo de erro ao campo e mostrar mensagem de erro
function setError(index){
    campos[index].style.border = '2px solid #f00';      // Adiciona uma borda vermelha ao campo
    spans[index].style.display = 'block';               // Mostra a mensagem de erro associada
}

// Define a função para remover o estilo de erro do campo e ocultar a mensagem de erro
function removeError(index){
    campos[index].style.border = '';                    // Remove a borda vermelha do campo
    spans[index].style.display = 'none';                // Oculta a mensagem de erro associada
}

function nameValidate(){
    if(campos[0].value.length < 4){
        setError(0);
        return false;
    }
    else
    {
        removeError(0)
        return true;
    }
}

function emailValidate(){
    if(!emailRegex.test(campos[1].value))
    {
        setError(1);
        return false;
    }
    else
    {
        removeError(1);
        return true;
    }
}

function mainPasswordValidate() {
    if (campos[2].value.length < 8) {
        setError(2);
        return false;
    } 
    else 
    {
        removeError(2);
        return true;
    }
}

// Função para comparar as senhas
function comparePassword() {
    if (campos[2].value === campos[3].value && campos[3].value.length >= 8) {
        removeError(3);
        return true;
    } 
    else 
    {
        setError(3);
        return false;
    }
}

// Função para validar o formulário como um todo
function validateForm() {
    let isValid = true;
    if (!nameValidate()) {
        isValid = false;
    }
    if (!emailValidate()) {
        isValid = false;
    }
    if (!mainPasswordValidate()) {
        isValid = false;
    }
    if (!comparePassword()) {
        isValid = false;
    }
    return isValid;
}

// Função para exibir uma mensagem
function addToFavorites(carouselNumber) {
    alert("Imagens do carrossel " + carouselNumber + " foram adicionadas aos favoritos!");
}

// Adicione o comportamento para os botões aqui
document.getElementById("btn-editar-perfil").addEventListener("click", function() {
    // Adicione aqui o código para abrir a página de edição de perfil
    console.log("Abrir página de edição de perfil");
});

document.getElementById("btn-mudar-tema").addEventListener("click", function() {
    // Adicione aqui o código para mudar o tema para dark
    // Por exemplo, você pode adicionar uma classe ao body para alterar o tema
    document.body.classList.toggle("dark-theme");
});