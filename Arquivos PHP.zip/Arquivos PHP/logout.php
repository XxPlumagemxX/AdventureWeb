<?php session_start(); ?>

<li class="item-menu <?php echo isset($_SESSION["logged_in"]) ? 'ligado' : ''; ?>">

    <?php if (isset($_SESSION["logged_in"])): ?>

        <a href="logout.php">
            <span class="icon"><i class="bi bi-door-open-fill"></i></span>
            <span class="txt-link">Logout</span>

        </a>

    <?php else: ?>

        <a href="login.html">
            <span class="icon"><i class="bi bi-door-open-fill"></i></span>
            <span class="txt-link">Login</span>
        </a>

    <?php endif; ?>
</li>