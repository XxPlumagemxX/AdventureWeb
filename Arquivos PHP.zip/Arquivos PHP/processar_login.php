<?php
session_start();

$servername = "localhost";
$username = "id21822032_isaac";
$password = "Grifo@381";
$database = "id21822032_tela";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["nome"]) && isset($_POST["senha"])) {
    $nome = $_POST["nome"];
    $senha = $_POST["senha"];

    $sql = "SELECT * FROM cadastro WHERE nome = '$nome'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (password_verify($senha, $row["senha"])) {
            // Definindo variáveis de sessão
            $_SESSION["nome"] = $nome;
            $_SESSION["senha"] = $senha;
            header("Location: sistema.php");
            exit();
        } else {
            echo "Senha incorreta";
        }
    } else {
        echo "Usuário não encontrado";
    }
} else {
    header("Location: login.html");
}

$conn->close();
?>
