<?php

$servername = "localhost";
$username = "id21822032_isaac";
$password = "Grifo@381";
$database = "id21822032_tela";

$conn = mysqli_connect($servername, $username, $password, $database);

if(!$conn){
    echo "Não foi possivel conectar!!!";
}


if($_SERVER["REQUEST_METHOD"] == "POST"){

    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $senha = $_POST["senha"];
    $confirmaSenha = $_POST["confirm_senha"];
    $descricao = $_POST["descricao"];
    $sexo = $_POST["sexo"];

    // Se a experiência foi selecionada
    if(isset($_POST["experiencias"])) {
        // Converta o array em uma string separada por vírgulas
        $experiencias = implode(", ", $_POST["experiencias"]);
    } else {
        // Se nenhuma experiência foi selecionada, defina como vazio
        $experiencias = "";
    }

    if($senha === $confirmaSenha){

        $sql = "SELECT * FROM cadastro WHERE nome = '$nome'";
        $retorno = mysqli_query($conn, $sql);
        $row = mysqli_fetch_assoc($retorno);

        if($row){

            echo "Usuario já existe";

        } else {

            $hashsenha = password_hash($senha, PASSWORD_BCRYPT);
            $sql = "INSERT INTO cadastro (nome, email, senha, descricao, experiencias, sexo) VALUES ('$nome', '$email', '$hashsenha', '$descricao', '$experiencias', 'sexo')";
            $retorno = mysqli_query($conn, $sql);

            if($retorno === true){

                echo "Cadastro Realizado";

            } else {
                echo "ERRO AO SE CADASTRAR:" . $conn->error;
            }

        }

    } else {

        echo "Senhas não são iguais!";

    }

}

//$conn->close();

?>