<?php
session_start();

if ((!isset($_SESSION["nome"])) || (!isset($_SESSION["senha"]))) {
    unset($_SESSION["nome"]);
    unset($_SESSION["senha"]);
    header("Location: login.html");
    exit(); // Importante adicionar exit() após o redirecionamento para evitar que o código continue sendo executado
}

$logado = $_SESSION["nome"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Sistema</title>
    <style>
        body{
            background:linear-gradient(to left, rgb(137, 252, 154), rgb(131, 189, 255));
}
    </style>
</head>
<body>
    <h1>Bem-vindo, <?php echo $logado; ?></h1>
    <p>Conteúdo do sistema...</p>
</body>
</html>